# Copyright (c) 2018 Intel Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Launch realsense2_camera node without rviz2."""
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.substitutions import ThisLaunchFileDir
from launch.launch_description_sources import PythonLaunchDescriptionSource
import sys
import pathlib
import launch_ros.actions
sys.path.append(str(pathlib.Path(__file__).parent.absolute()))
import rs_launch

local_parameters = [{'name': 'camera_name1', 'default': 'L515', 'description': 'camera unique name'},
                    {'name': 'device_type1', 'default': 'l515', 'description': 'choose device by type'},
                    {'name': 'enable_sync1', 'default': 'true', 'description': 'choose sync'},
                    #{'name': 'initial_reset1', 'default': 'true', 'description': "''"},


                    {'name': 'depth_module.profile', 'default': '640x480x30', 'description': 'depth module profile'},                    
                    {'name': 'rgb_camera.profile', 'default': '640x480x30', 'description': 'color image width'},

                    {'name': 'enable_gyro1', 'default': 'false', 'description': "''"},                           
                    {'name': 'enable_accel1', 'default': 'false', 'description': "''"}, 


                    {'name': 'camera_name2', 'default': 't265', 'description': 'camera unique name'},
                    {'name': 'device_type2', 'default': 't265', 'description': 'choose device by type'},
                    {'name': 'enable_sync2', 'default': 'true', 'description': 'choose sync'},
                    #{'name': 'tf_publish_rate2', 'default': '30.0', 'description': 'Rate of publishing static_tf'},
                    #{'name': 'pose_fps2',  'default': '100', 'description': "''"},


                    {'name': 'enable_gyro2', 'default': 'true', 'description': "''"},                           
                    {'name': 'enable_accel2', 'default': 'true', 'description': "''"},  
                    {'name': 'enable_pose2', 'default': 'true', 'description': "''"},

                    {'name': 'enable_fisheye1', 'default': 'true', 'description': 'enable fisheye1 stream'},
                    {'name': 'enable_fisheye2', 'default': 'true', 'description': 'enable fisheye2 stream'},

                    #{'name': 'topic_odom_in', 'default': '/odom', 'description': 'topic for T265 wheel odometry'},
                    #{'name': 'tf_publish_rate', 'default': '200', 'description': 'Rate of publishing static_tf'},
                   ]

def generate_launch_description():
    return LaunchDescription(
        rs_launch.declare_configurable_parameters(local_parameters) + 
        [
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([ThisLaunchFileDir(), '/rs_multi_camera_launch.py']),
            launch_arguments=rs_launch.set_configurable_parameters(local_parameters).items(),
        ),
        # dummy static transformation from camera1 to camera2
        #launch_ros.actions.Node(
        #    package = "tf2_ros",
        #    executable = "static_transform_publisher",
        #    arguments = ["0", "0", "0", "0", "0", "0", "T265_link", "L515_link"]
        #),
        
    ])
