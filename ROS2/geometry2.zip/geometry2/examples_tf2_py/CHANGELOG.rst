^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package examples_tf2_py
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.13.14 (2023-03-16)
--------------------

0.13.13 (2022-01-31)
--------------------

0.13.12 (2021-10-05)
--------------------

0.13.11 (2021-08-31)
--------------------

0.13.10 (2021-04-14)
--------------------

0.13.9 (2020-12-09)
-------------------

0.13.8 (2020-12-08)
-------------------

0.13.7 (2020-11-18)
-------------------

0.13.6 (2020-10-28)
-------------------
* Update maintainers of the ros2/geometry2 fork. (`#328 <https://github.com/ros2/geometry2/issues/328>`_) (`#332 <https://github.com/ros2/geometry2/issues/332>`_)
* Add pytest.ini so local tests don't display warning (`#276 <https://github.com/ros2/geometry2/issues/276>`_)
* Contributors: Alejandro Hernández Cordero, Chris Lalancette

0.13.5 (2020-08-05)
-------------------

0.13.4 (2020-06-03)
-------------------

0.13.3 (2020-05-26)
-------------------

0.13.2 (2020-05-18)
-------------------

0.13.1 (2020-05-08)
-------------------

0.13.0 (2020-04-30)
-------------------
* more verbose test_flake8 error messages (same as `ros2/launch_ros#135 <https://github.com/ros2/launch_ros/issues/135>`_)
* Contributors: Dirk Thomas

0.12.4 (2019-11-19)
-------------------
* Add Python examples for tf2_ros (`#161 <https://github.com/ros2/geometry2/issues/161>`_)
